//
//  MD5.h
//  text
//
//  Created by Apple6 on 16/4/9.
//  Copyright © 2016年 Apple6. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CommonCrypto/CommonCryptor.h>

@interface MD5 : NSObject
// MD5 加密
+(NSString*)getFileMD5WithPath:(NSString*)path;

@end
