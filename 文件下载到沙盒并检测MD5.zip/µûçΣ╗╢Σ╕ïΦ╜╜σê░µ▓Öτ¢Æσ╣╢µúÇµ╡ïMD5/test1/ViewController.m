//
//  ViewController.m
//  test1
//
//  Created by Apple6 on 16/4/11.
//  Copyright © 2016年 Apple6. All rights reserved.
//

#import "ViewController.h"

#import "AFNetworking.h"

#import "MD5.h"

@interface ViewController ()<NSURLSessionDownloadDelegate> {
    NSURLSession *_session;
    NSURLSessionDownloadTask *_task; //断点续传的下载任务
}

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self loadImage];//用iOS7以后自带的NSURLSession
    //[self loadImage2];//用AF objc版 3.1.0 需引用 AFNetworking.h 和 UIKit+AFNetworking.h
}

//用iOS7以后自带的NSURLSession
- (void)loadImage
{

    NSURL *url = [NSURL
                  URLWithString:@"http://www.ykipa.com/test.jpg"];
    NSURLRequest *request =
    [NSURLRequest requestWithURL:url
                     cachePolicy:NSURLRequestUseProtocolCachePolicy
                 timeoutInterval:120];
    
    NSURLSessionConfiguration *config =
    [NSURLSessionConfiguration defaultSessionConfiguration];
    
    _session = [NSURLSession sessionWithConfiguration:config
                                             delegate:self
                                        delegateQueue:[NSOperationQueue mainQueue]];
    
    _task = [_session downloadTaskWithRequest:request];
    
    [_task resume];

}

#pragma mark - 下载的代理方法

- (void)URLSession:(NSURLSession *)session
      downloadTask:(NSURLSessionDownloadTask *)downloadTask
      didWriteData:(int64_t)bytesWritten
 totalBytesWritten:(int64_t)totalBytesWritten
totalBytesExpectedToWrite:(int64_t)totalBytesExpectedToWrite {
    
    float progress = totalBytesWritten / (float)totalBytesExpectedToWrite;
    NSLog(@"%f",progress);
}

// 2.下载完成调用（必须实现）
- (void)URLSession:(NSURLSession *)session
      downloadTask:(NSURLSessionDownloadTask *)downloadTask
didFinishDownloadingToURL:(NSURL *)location {
    NSString *caches = [NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask, YES) lastObject];
    
    NSString *file = [caches stringByAppendingPathComponent:@"text.jpg"];
    
    NSLog(@"=========%@",file);
    // 将临时文件剪切或者复制Caches文件夹
    NSFileManager *mgr = [NSFileManager defaultManager];
    
    if(![mgr fileExistsAtPath:file]) {
        NSLog(@"文件不存在,已经下载");
        // AtPath : 剪切前的文件路径
        // ToPath : 剪切后的文件路径
          [mgr moveItemAtPath:location.path toPath:file error:nil];
    } else {
        NSLog(@"文件存在，已经删除");
        [mgr createDirectoryAtPath:file withIntermediateDirectories:YES attributes:nil error:nil];
    }
    
    NSString *md5 = [MD5 getFileMD5WithPath:file];
    NSLog(@"文件的md5的值＝＝＝＝＝%@",md5);
}



//用AF objc版 3.1.0 需引用 AFNetworking.h 和 UIKit+AFNetworking.h
- (void)loadImage2
{
    NSURL* url = [NSURL URLWithString:@"http://www.ykipa.com/test.jpg"];
    AFHTTPSessionManager *manager1 = [AFHTTPSessionManager manager];
    NSURLRequest *req = [NSURLRequest requestWithURL:url];
    
    NSURLSessionDownloadTask *downloadTask = [manager1 downloadTaskWithRequest:req progress:^(NSProgress * _Nonnull downloadProgress) {
        NSLog(@"%f",downloadProgress.fractionCompleted);
    } destination:^NSURL *(NSURL *targetPath, NSURLResponse *response) {
        
        NSString *caches = [NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask, YES) lastObject];
        NSString *file = [caches stringByAppendingPathComponent:@"text.jpg"];
        NSLog(@"=========%@",file);
        NSFileManager *mgr = [NSFileManager defaultManager];
        [mgr moveItemAtPath:targetPath.path toPath:file error:nil];
        
        return [NSURL URLWithString:file];
    } completionHandler:^(NSURLResponse *response, NSURL *filePath, NSError *error) {
        
        NSString *md5 = [MD5 getFileMD5WithPath:filePath.path];
        NSLog(@"文件的地址是!~~~~~~~~%@",filePath.path);
        NSLog(@"文件的md5的值＝＝＝＝＝%@",md5);
        
    }];
    
    [downloadTask resume];
}



@end